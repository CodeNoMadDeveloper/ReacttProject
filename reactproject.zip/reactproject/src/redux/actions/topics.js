import { createActions } from 'reduxsauce'

const { Types, Creators } = createActions({
})

export { Types, Creators }
